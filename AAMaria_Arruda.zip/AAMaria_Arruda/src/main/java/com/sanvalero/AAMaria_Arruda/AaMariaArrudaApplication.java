package com.sanvalero.AAMaria_Arruda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AaMariaArrudaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AaMariaArrudaApplication.class, args);
	}

}
