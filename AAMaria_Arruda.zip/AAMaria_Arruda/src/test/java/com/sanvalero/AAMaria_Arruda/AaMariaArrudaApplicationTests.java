package com.sanvalero.AAMaria_Arruda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AaMariaArrudaApplicationTests {

	@Test
	void contextLoads() {
	}

}
